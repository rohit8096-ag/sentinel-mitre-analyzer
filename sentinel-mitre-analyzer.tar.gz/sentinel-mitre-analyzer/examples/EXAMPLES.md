# Example Usage Scripts

Collection of practical examples for using the Sentinel MITRE Analyzer.

---

## Example 1: Basic Report Generation

```powershell
# Import the module
Import-Module .\SentinelMITREAnalyzer.psm1

# Authenticate
Connect-AzAccount

# Run the analyzer (interactive mode)
Get-SentinelAnalyticalRulesReport -ExportHtml

# Open the report
$reportPath = Join-Path $env:USERPROFILE "Downloads\Sentinel Analytical Analyzer.html"
Start-Process $reportPath
```

---

## Example 2: Automated Monthly Report

```powershell
# Script: Monthly-Sentinel-Report.ps1
# Schedule this with Windows Task Scheduler

param(
    [string]$SubscriptionId = "your-sub-id",
    [string]$ResourceGroup = "sentinel-rg",
    [string]$WorkspaceName = "sentinel-workspace"
)

# Import module
Import-Module .\SentinelMITREAnalyzer.psm1

# Authenticate (use service principal for automation)
$tenantId = "your-tenant-id"
$appId = "your-app-id"
$secret = ConvertTo-SecureString "your-secret" -AsPlainText -Force
$credential = New-Object System.Management.Automation.PSCredential($appId, $secret)

Connect-AzAccount -ServicePrincipal -Credential $credential -Tenant $tenantId

# Generate report
$report = Get-SentinelAnalyticalRulesReport `
    -SubscriptionId $SubscriptionId `
    -ResourceGroup $ResourceGroup `
    -WorkspaceName $WorkspaceName `
    -ExportHtml

# Rename with timestamp
$timestamp = Get-Date -Format "yyyy-MM-dd"
$newName = "Sentinel_Report_$timestamp.html"
$downloadsPath = Join-Path $env:USERPROFILE "Downloads"
$oldPath = Join-Path $downloadsPath "Sentinel Analytical Analyzer.html"
$newPath = Join-Path $downloadsPath $newName

Move-Item -Path $oldPath -Destination $newPath -Force

Write-Host "Report saved: $newPath"

# Optional: Email the report
Send-MailMessage `
    -To "security-team@company.com" `
    -From "sentinel-reports@company.com" `
    -Subject "Monthly Sentinel Coverage Report - $timestamp" `
    -Body "See attached report" `
    -Attachments $newPath `
    -SmtpServer "smtp.company.com"
```

---

## Example 3: Multi-Workspace Comparison

```powershell
# Compare coverage across multiple workspaces

$workspaces = @(
    @{ Sub="xxx"; RG="prod-rg"; WS="prod-sentinel"; Env="Production" },
    @{ Sub="xxx"; RG="dev-rg"; WS="dev-sentinel"; Env="Development" },
    @{ Sub="xxx"; RG="test-rg"; WS="test-sentinel"; Env="Testing" }
)

$results = @()

foreach ($ws in $workspaces) {
    Write-Host "Analyzing $($ws.Env) workspace..." -ForegroundColor Cyan
    
    $report = Get-SentinelAnalyticalRulesReport `
        -SubscriptionId $ws.Sub `
        -ResourceGroup $ws.RG `
        -WorkspaceName $ws.WS `
        -ExportHtml:$false
    
    # Calculate coverage
    $uniqueTechs = [System.Collections.Generic.HashSet[string]]::new()
    foreach ($rule in $report.Enabled) {
        $mitre = Extract-MitreData $rule
        foreach ($tech in $mitre.Techniques) {
            $base = Get-TechniqueBase $tech
            [void]$uniqueTechs.Add($base)
        }
    }
    
    $results += [PSCustomObject]@{
        Environment = $ws.Env
        TotalRules = $report.Rules.Count
        EnabledRules = $report.Enabled.Count
        DisabledRules = $report.Disabled.Count
        TechniquesCovered = $uniqueTechs.Count
        CoveragePercent = [math]::Round(($uniqueTechs.Count / 211) * 100, 1)
    }
}

# Display comparison
$results | Format-Table -AutoSize

# Export to CSV
$results | Export-Csv "Workspace_Comparison_$(Get-Date -Format 'yyyy-MM-dd').csv" -NoTypeInformation
```

---

## Example 4: Identify High-Risk Gaps

```powershell
# Find critical coverage gaps

$report = Get-SentinelAnalyticalRulesReport

# Critical tactics with zero or low coverage
$criticalTactics = @("InitialAccess", "Execution", "Persistence", "PrivilegeEscalation")

Write-Host "`n=== CRITICAL COVERAGE GAPS ===" -ForegroundColor Red
Write-Host ""

foreach ($tactic in $criticalTactics) {
    if ($report.TacticStats[$tactic]) {
        $count = $report.TacticStats[$tactic].EnabledCount
        
        if ($count -eq 0) {
            Write-Host "CRITICAL: No coverage for $tactic" -ForegroundColor Red
        } elseif ($count -le 3) {
            Write-Host "WARNING: Low coverage for $tactic ($count rules)" -ForegroundColor Yellow
        } else {
            Write-Host "OK: $tactic has $count enabled rules" -ForegroundColor Green
        }
    } else {
        Write-Host "CRITICAL: No rules found for $tactic" -ForegroundColor Red
    }
}

# High-severity disabled rules
Write-Host "`n=== HIGH-SEVERITY DISABLED RULES ===" -ForegroundColor Red
Write-Host ""

$highSevDisabled = $report.Disabled | 
    Where-Object { $_.properties.severity -eq 'High' }

if ($highSevDisabled) {
    foreach ($rule in $highSevDisabled) {
        Write-Host "⚠ $($rule.properties.displayName)" -ForegroundColor Yellow
        Write-Host "  Tactics: $($rule.properties.tactics -join ', ')" -ForegroundColor Gray
    }
    Write-Host "`nTotal high-severity disabled: $($highSevDisabled.Count)" -ForegroundColor Red
} else {
    Write-Host "✓ No high-severity rules are disabled" -ForegroundColor Green
}
```

---

## Example 5: Export to Multiple Formats

```powershell
# Export data in various formats for different stakeholders

$report = Get-SentinelAnalyticalRulesReport -ExportHtml

# 1. Executive summary (JSON)
$summary = @{
    Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    TotalRules = $report.Rules.Count
    EnabledRules = $report.Enabled.Count
    DisabledRules = $report.Disabled.Count
    HighSeverityDisabled = ($report.Disabled | Where-Object { $_.properties.severity -eq 'High' }).Count
}
$summary | ConvertTo-Json | Out-File "summary.json"

# 2. Disabled rules (CSV)
$report.Disabled | Select-Object `
    @{N='Rule';E={$_.properties.displayName}},
    @{N='Severity';E={$_.properties.severity}},
    @{N='Tactics';E={$_.properties.tactics -join ';'}},
    @{N='LastModified';E={$_.properties.lastModifiedUtc}} |
Export-Csv "disabled_rules.csv" -NoTypeInformation

# 3. Coverage by tactic (CSV)
$tacticCoverage = $report.TacticStats.GetEnumerator() | ForEach-Object {
    [PSCustomObject]@{
        Tactic = $_.Key
        EnabledRules = $_.Value.EnabledCount
        TotalRules = $_.Value.Total
    }
}
$tacticCoverage | Export-Csv "tactic_coverage.csv" -NoTypeInformation

Write-Host "Exported:"
Write-Host "  - summary.json"
Write-Host "  - disabled_rules.csv"
Write-Host "  - tactic_coverage.csv"
Write-Host "  - $($report.HtmlPath)"
```

---

## Example 6: Slack/Teams Notification

```powershell
# Send coverage report to Slack/Teams

$report = Get-SentinelAnalyticalRulesReport -ExportHtml:$false

# Calculate coverage grade
$uniqueTechs = [System.Collections.Generic.HashSet[string]]::new()
foreach ($rule in $report.Enabled) {
    $mitre = Extract-MitreData $rule
    foreach ($tech in $mitre.Techniques) {
        [void]$uniqueTechs.Add((Get-TechniqueBase $tech))
    }
}
$coverage = [math]::Round(($uniqueTechs.Count / 211) * 100, 1)

$grade = if ($coverage -ge 80) { "A 🎉" }
    elseif ($coverage -ge 60) { "B ✅" }
    elseif ($coverage -ge 40) { "C ⚠️" }
    else { "D/F ❌" }

# Slack webhook payload
$slackPayload = @{
    text = "Sentinel Coverage Report"
    blocks = @(
        @{
            type = "header"
            text = @{ type = "plain_text"; text = "🛡️ Sentinel MITRE Coverage Report" }
        },
        @{
            type = "section"
            fields = @(
                @{ type = "mrkdwn"; text = "*Total Rules:*`n$($report.Rules.Count)" },
                @{ type = "mrkdwn"; text = "*Enabled:*`n$($report.Enabled.Count)" },
                @{ type = "mrkdwn"; text = "*Coverage:*`n$coverage%" },
                @{ type = "mrkdwn"; text = "*Grade:*`n$grade" }
            )
        }
    )
} | ConvertTo-Json -Depth 10

# Send to Slack
$webhookUrl = "https://hooks.slack.com/services/YOUR/WEBHOOK/URL"
Invoke-RestMethod -Uri $webhookUrl -Method Post -Body $slackPayload -ContentType 'application/json'
```

---

## Example 7: Continuous Monitoring (Azure Automation)

```powershell
# Azure Automation Runbook

param(
    [string]$SubscriptionId,
    [string]$ResourceGroup,
    [string]$WorkspaceName
)

# Authenticate with Managed Identity
Connect-AzAccount -Identity

# Import module (upload to Automation Account assets first)
Import-Module SentinelMITREAnalyzer

# Run analysis
$report = Get-SentinelAnalyticalRulesReport `
    -SubscriptionId $SubscriptionId `
    -ResourceGroup $ResourceGroup `
    -WorkspaceName $WorkspaceName `
    -ExportHtml:$false

# Check for critical issues
$criticalDisabled = $report.Disabled | 
    Where-Object { $_.properties.severity -eq 'High' }

if ($criticalDisabled.Count -gt 0) {
    # Alert
    Write-Output "ALERT: $($criticalDisabled.Count) high-severity rules are disabled!"
    
    # Could trigger Logic App, send email, create incident, etc.
} else {
    Write-Output "OK: All high-severity rules are enabled"
}

# Log metrics
Write-Output "Enabled: $($report.Enabled.Count)"
Write-Output "Disabled: $($report.Disabled.Count)"
```

---

## Example 8: CI/CD Pipeline Integration

```yaml
# Azure DevOps Pipeline

trigger:
  - main

pool:
  vmImage: 'windows-latest'

steps:
- task: PowerShell@2
  displayName: 'Analyze Sentinel Coverage'
  inputs:
    targetType: 'inline'
    script: |
      # Install Az module
      Install-Module Az -Force -AllowClobber -Scope CurrentUser
      
      # Login with service principal
      $securePassword = ConvertTo-SecureString $env:AZURE_SP_PASSWORD -AsPlainText -Force
      $credential = New-Object System.Management.Automation.PSCredential($env:AZURE_SP_ID, $securePassword)
      Connect-AzAccount -ServicePrincipal -Credential $credential -Tenant $env:AZURE_TENANT_ID
      
      # Run analyzer
      Import-Module ./SentinelMITREAnalyzer.psm1
      $report = Get-SentinelAnalyticalRulesReport `
        -SubscriptionId $env:AZURE_SUBSCRIPTION_ID `
        -ResourceGroup $env:RESOURCE_GROUP `
        -WorkspaceName $env:WORKSPACE_NAME `
        -ExportHtml
      
      # Check coverage threshold
      $coverage = [math]::Round(($report.Enabled.Count / $report.Rules.Count) * 100, 1)
      if ($coverage -lt 80) {
        Write-Host "##vso[task.logissue type=warning]Coverage below 80%: $coverage%"
      }

- task: PublishBuildArtifacts@1
  displayName: 'Publish Report'
  inputs:
    PathtoPublish: '$(Agent.TempDirectory)/Sentinel Analytical Analyzer.html'
    ArtifactName: 'sentinel-report'
```

---

## Tips for All Examples

1. **Always authenticate first** before running the analyzer
2. **Store credentials securely** (Azure Key Vault, environment variables)
3. **Use service principals** for automation scenarios
4. **Handle errors gracefully** with try-catch blocks
5. **Log results** for auditing and troubleshooting
6. **Schedule regular runs** to track coverage over time

---

**More Examples?** Check the [GitHub repository](https://github.com/yourusername/sentinel-mitre-analyzer/tree/main/examples)
